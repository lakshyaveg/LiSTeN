var LSTN = LSTN || {};

/**
 * Responsibility: display image catalog with grid layout, pagination, and selection.
 * Uses local image files referenced by relative path.
 */
LSTN.ImageCatalog = class {
  constructor(onImageSelected, onCatalogClosed, imageLoader) {
    this.onImageSelected = onImageSelected;
    this.onCatalogClosed = onCatalogClosed || function() {};
    this.imageLoader = imageLoader;
    this.isOpen = false;
    this.currentPage = 0;
    this.itemsPerPage = 6; // 3 columns x 2 rows
    this.itemsPerRow = 3;
    
    // Local image files: add image files to your workspace and reference them here.
    // Example: { name: "MyImage", data: "images/MyImage.png" }
    // If you add files in the root, use relative paths from index-1.html.
  
    this.items = [
      { name: "MyImage", data: "images/MyImage.png", thumbnail: null },
      { name: "Nyan Cat Background GIF", data: "images/nyancat.gif", thumbnail: null },
      { name: "Nyan Cat Static PNG", data: "images/nyan.png", thumbnail: null },
      { name: "Evil Nyan Cat", data: "images/evilnyan.png", thumbnail: null }
      // { name: "OtherImage", data: "images/OtherImage.jpg", thumbnail: null },
    ];

    this.hoveredIndex = null;
    this.pendingSelection = null;
    this.directTarget = null;
  }

  setDirectTarget(target) {
    this.directTarget = target;
  }

  ensureImagesCreated() {
    for (let item of this.items) {
      if (item.data && item.thumbnail == null && !item.thumbnailLoading) {
        item.thumbnailLoading = true;
        this.imageLoader.loadFromData(item.data,
          (img) => {
            item.thumbnail = img;
            item.thumbnailLoading = false;
          }
        );
      }
    }
  }

  toggle() {
    this.isOpen = !this.isOpen;
    if (this.isOpen) {
      this.currentPage = 0;
    }
  }

  open() {
    this.isOpen = true;
    this.currentPage = 0;
    this.pendingSelection = null;
  }

  close() {
    this.isOpen = false;
    this.directTarget = null;
  }

  handleCloseClick(mouseX, mouseY) {
    const containerW = 420;
    const containerX = width / 2 - containerW / 2;
    const containerY = height / 2 - 380 / 2;
    const closeSize = 26;
    const closeX = containerX + containerW - closeSize - 14;
    const closeY = containerY + 14;

    if (
      mouseX >= closeX &&
      mouseX <= closeX + closeSize &&
      mouseY >= closeY &&
      mouseY <= closeY + closeSize
    ) {
      this.close();
      this.onCatalogClosed();
      return true;
    }
    return false;
  }

  handleMousePressed(mouseX, mouseY) {
    if (!this.isOpen) return;

    if (this.handleCloseClick(mouseX, mouseY)) {
      return;
    }

    if (this.pendingSelection) {
      if (this.handleChoiceClick(mouseX, mouseY)) {
        return;
      }
      return;
    }

    const index = this.getItemIndexAtMouse(mouseX, mouseY);
    if (index !== null && index < this.items.length) {
      const item = this.items[index];
      if (this.directTarget) {
        this.onImageSelected(item.data, this.directTarget);
        this.directTarget = null;
        this.close();
        this.onCatalogClosed();
        return;
      }
      this.pendingSelection = item;
    }
  }

  handleKeyPressed(key) {
    if (!this.isOpen) return;

    if (this.pendingSelection) {
      return;
    }

    if (key === "ArrowLeft" || key === "Left") {
      this.previousPage();
    } else if (key === "ArrowRight" || key === "Right") {
      this.nextPage();
    } else if (keyCode === ESCAPE || key === "Escape") {
      this.close();
    }
  }

  handleChoiceClick(mouseX, mouseY) {
    const promptWidth = 380;
    const promptHeight = 180;
    const promptX = width / 2 - promptWidth / 2;
    const promptY = height / 2 - promptHeight / 2;
    const buttonW = 150;
    const buttonH = 40;
    const buttonY = promptY + promptHeight - 60;
    const backgroundButtonX = promptX + 30;
    const heartButtonX = promptX + promptWidth - buttonW - 30;
    const closeSize = 22;
    const closeX = promptX + promptWidth - closeSize - 12;
    const closeY = promptY + 12;

    if (
      mouseX >= closeX &&
      mouseX <= closeX + closeSize &&
      mouseY >= closeY &&
      mouseY <= closeY + closeSize
    ) {
      this.pendingSelection = null;
      return true;
    }

    if (
      mouseX >= backgroundButtonX &&
      mouseX <= backgroundButtonX + buttonW &&
      mouseY >= buttonY &&
      mouseY <= buttonY + buttonH
    ) {
      this.selectChoice("background");
      return true;
    }

    if (
      mouseX >= heartButtonX &&
      mouseX <= heartButtonX + buttonW &&
      mouseY >= buttonY &&
      mouseY <= buttonY + buttonH
    ) {
      this.selectChoice("heart");
      return true;
    }

    return false;
  }

  selectChoice(choice) {
    if (!this.pendingSelection) return;

    if (choice === "background") {
      this.onImageSelected(this.pendingSelection.data, "background");
      this.pendingSelection = null;
      this.close();
      this.onCatalogClosed();
    } else if (choice === "heart") {
      this.onImageSelected(this.pendingSelection.data, "heart");
      this.pendingSelection = null;
      this.close();
      this.onCatalogClosed();
    }
  }

  nextPage() {
    const maxPage = Math.ceil(this.items.length / this.itemsPerPage) - 1;
    if (this.currentPage < maxPage) {
      this.currentPage++;
    }
  }

  previousPage() {
    if (this.currentPage > 0) {
      this.currentPage--;
    }
  }

  getItemIndexAtMouse(mouseX, mouseY) {
    const startIdx = this.currentPage * this.itemsPerPage;
    const baseX = width / 2 - 180;
    const baseY = height / 2 - 140;
    const itemSize = 120;
    const spacing = 20;

    for (let i = 0; i < this.itemsPerPage; i++) {
      if (startIdx + i >= this.items.length) break;

      const row = Math.floor(i / this.itemsPerRow);
      const col = i % this.itemsPerRow;
      const x = baseX + col * (itemSize + spacing);
      const y = baseY + row * (itemSize + spacing);

      if (
        mouseX >= x &&
        mouseX < x + itemSize &&
        mouseY >= y &&
        mouseY < y + itemSize
      ) {
        return startIdx + i;
      }
    }
    return null;
  }

  drawChoicePrompt() {
    const item = this.pendingSelection;
    if (!item) return;

    const promptW = 380;
    const promptH = 180;
    const promptX = width / 2 - promptW / 2;
    const promptY = height / 2 - promptH / 2;
    const buttonW = 150;
    const buttonH = 40;
    const buttonY = promptY + promptH - 60;
    const backgroundButtonX = promptX + 30;
    const heartButtonX = promptX + promptW - buttonW - 30;

    fill(30, 30, 30, 230);
    stroke(255);
    strokeWeight(2);
    rect(promptX, promptY, promptW, promptH, 12);

    fill(255);
    noStroke();
    textAlign(CENTER, TOP);
    textSize(16);
    text(`Use "${item.name}" as...`, width / 2, promptY + 20);

    textSize(12);
    textStyle(NORMAL);
    text(
      "Choose whether to replace the background or the default heart image.",
      width / 2,
      promptY + 50
    );

    // Buttons
    fill(255, 105, 180);
    rect(backgroundButtonX, buttonY, buttonW, buttonH, 8);
    rect(heartButtonX, buttonY, buttonW, buttonH, 8);

    fill(255);
    textSize(14);
    textStyle(BOLD);
    text("Background", backgroundButtonX + buttonW / 2, buttonY + buttonH / 2 - 8);
    text("Heart", heartButtonX + buttonW / 2, buttonY + buttonH / 2 - 8);

    this.drawPromptCloseButton(promptX, promptY, promptW);
    textSize(11);
    textStyle(NORMAL);
    text("Click X to cancel prompt", width / 2, promptY + promptH - 20);
  }

  drawPromptCloseButton(promptX, promptY, promptWidth) {
    const closeSize = 22;
    const closeX = promptX + promptWidth - closeSize - 12;
    const closeY = promptY + 12;

    fill(255, 180);
    noStroke();
    rect(closeX, closeY, closeSize, closeSize, 6);

    stroke(255);
    strokeWeight(2);
    line(closeX + 5, closeY + 5, closeX + closeSize - 5, closeY + closeSize - 5);
    line(closeX + closeSize - 5, closeY + 5, closeX + 5, closeY + closeSize - 5);
  }

  drawCloseButton(containerX, containerY, containerW) {
    const closeSize = 26;
    const closeX = containerX + containerW - closeSize - 14;
    const closeY = containerY + 14;

    fill(255, 180);
    noStroke();
    rect(closeX, closeY, closeSize, closeSize, 6);

    stroke(255);
    strokeWeight(2);
    line(closeX + 7, closeY + 7, closeX + closeSize - 7, closeY + closeSize - 7);
    line(closeX + closeSize - 7, closeY + 7, closeX + 7, closeY + closeSize - 7);
  }

  draw() {
    if (!this.isOpen) return;

    // Create images on first draw
    this.ensureImagesCreated();

    push();
    resetMatrix();

    // Overlay background
    fill(0, 0, 0, 200);
    rect(0, 0, width, height);

    // Catalog container
    const containerW = 420;
    const containerH = 380;
    const containerX = width / 2 - containerW / 2;
    const containerY = height / 2 - containerH / 2;

    fill(255, 20, 147); // Deep pink
    stroke(255, 105, 180); // Hot pink border
    strokeWeight(3);
    rect(containerX, containerY, containerW, containerH, 10);

    // Title
    fill(255);
    textAlign(CENTER, TOP);
    textSize(20);
    textFont("Arial");
    textStyle(BOLD);
    text("IMAGE CATALOG", width / 2, containerY + 15);

    // Items grid
    const startIdx = this.currentPage * this.itemsPerPage;
    const baseX = containerX + 30;
    const baseY = containerY + 50;
    const itemSize = 100;
    const spacing = 20;

    for (let i = 0; i < this.itemsPerPage; i++) {
      const itemIdx = startIdx + i;
      if (itemIdx >= this.items.length) break;

      const row = Math.floor(i / this.itemsPerRow);
      const col = i % this.itemsPerRow;
      const x = baseX + col * (itemSize + spacing);
      const y = baseY + row * (itemSize + spacing);

      // Item background
      fill(255, 105, 180);
      stroke(255, 182, 193);
      strokeWeight(2);
      rect(x, y, itemSize, itemSize, 5);

      // Item image
      const item = this.items[itemIdx];
      if (item.thumbnail) {
        tint(255, 255, 255, 220);
        imageMode(CENTER);
        image(item.thumbnail, x + itemSize / 2, y + itemSize / 2, 80, 80);
        noTint();
      } else {
        fill(255);
        textAlign(CENTER, CENTER);
        textSize(48);
        text("🖼", x + itemSize / 2, y + itemSize / 2);
      }

      // Item name (below the box)
      fill(255);
      noStroke();
      textAlign(CENTER, TOP);
      textSize(12);
      textStyle(NORMAL);
      text(item.name, x + itemSize / 2, y + itemSize + 5);
    }

    // Navigation info
    const maxPage = Math.ceil(this.items.length / this.itemsPerPage) - 1;
    fill(255);
    textAlign(CENTER, BOTTOM);
    textSize(12);
    text(
      `Page ${this.currentPage + 1} / ${maxPage + 1}  |  Arrow Keys to navigate `,
      width / 2,
      containerY + containerH - 10
    );

    this.drawCloseButton(containerX, containerY, containerW);

    if (this.pendingSelection) {
      this.drawChoicePrompt();
    }

    pop();
  }

};
