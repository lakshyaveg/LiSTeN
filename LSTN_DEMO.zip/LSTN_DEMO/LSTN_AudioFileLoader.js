var LSTN = LSTN || {};

/**
 * Responsibility: load and manage MP3 files for audio visualization.
 */
LSTN.AudioFileLoader = class {
  constructor() {
    this.currentAudio = null;
    this.isPlaying = false;
  }

  load(file, onLoaded) {
    // Stop any existing audio
    if (this.currentAudio && this.currentAudio.isPlaying()) {
      this.currentAudio.stop();
    }

    // Use p5's loadSound directly on file.data
    this.currentAudio = loadSound(file.data, () => {
      console.log("Audio file loaded successfully");
      this.currentAudio.loop();
      this.isPlaying = true;
      onLoaded(this.currentAudio);
    });
  }

  play() {
    if (this.currentAudio && !this.isPlaying) {
      this.currentAudio.play();
      this.isPlaying = true;
    }
  }

  pause() {
    if (this.currentAudio && this.isPlaying) {
      this.currentAudio.pause();
      this.isPlaying = false;
    }
  }

  stop() {
    if (this.currentAudio) {
      this.currentAudio.stop();
      this.isPlaying = false;
    }
  }

  getAudio() {
    return this.currentAudio;
  }
};
