var LSTN = LSTN || {};

/**
 * Responsibility: convert file data into a p5.Image (async) with caching.
 */
LSTN.ImageLoader = class {
  constructor(maxCacheSize = 20) {
    this.cache = new Map(); // URL -> p5.Image
    this.usageOrder = []; // For LRU eviction
    this.maxCacheSize = maxCacheSize;
  }

  loadFromData(data, onLoaded) {
    // Check cache first
    if (this.cache.has(data)) {
      this.updateUsage(data);
      onLoaded(this.cache.get(data));
      return;
    }

    // Load new image
    loadImage(data, (img) => {
      // Evict oldest if cache is full
      if (this.cache.size >= this.maxCacheSize) {
        const oldest = this.usageOrder.shift();
        this.cache.delete(oldest);
      }

      // Cache the loaded image
      this.cache.set(data, img);
      this.usageOrder.push(data);
      onLoaded(img);
    }, (error) => {
      console.warn("Failed to load image:", data, error);
      onLoaded(null);
    });
  }

  updateUsage(data) {
    const index = this.usageOrder.indexOf(data);
    if (index > -1) {
      this.usageOrder.splice(index, 1);
      this.usageOrder.push(data);
    }
  }

  clearCache() {
    this.cache.clear();
    this.usageOrder = [];
  }

  getCacheSize() {
    return this.cache.size;
  }
};
