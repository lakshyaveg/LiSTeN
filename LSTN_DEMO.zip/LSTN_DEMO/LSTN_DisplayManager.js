var LSTN = LSTN || {};

/**
 * Responsibility: fullscreen toggling and canvas resizing.
 */
LSTN.DisplayManager = class {
  toggleFullscreen() {
    const fs = !fullscreen();
    fullscreen(fs);
    resizeCanvas(windowWidth - 25, windowHeight - 25);
  }

  handleWindowResized() {
    resizeCanvas(windowWidth - 25, windowHeight - 25);
  }
};
