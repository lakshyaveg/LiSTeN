var LSTN = LSTN || {};

/**
 * Responsibility: map raw key events -> command names (pure mapping, no side effects).
 */
LSTN.KeyBindings = class {
  getCommandForKey(key, keyCode, mode = "normal") {
    if (keyCode === ENTER) return "SET_HEART";
    if (keyCode === LEFT_ARROW || keyCode === DOWN_ARROW) return "PREVIOUS_BG_COLOR";
    if (keyCode === RIGHT_ARROW || keyCode === UP_ARROW) return "NEXT_BG_COLOR";
    if (keyCode === DELETE || key === "d" || key === "D") return "DELETE_SELECTED";
    if (key === "r" || key === "R") return "TOGGLE_ROTATE";
    if (key === "b" || key === "B") return "TOGGLE_BOUNCE";
    if (key === "a" || key === "A") return "TOGGLE_MODE";
    if (key === "h" || key === "H") return "SET_HEART_TYPE";
    if (key === "e" || key === "E") return "TOGGLE_INSTRUCTIONS";
    if (key === "x" || key === "X") return "RESET_ALL";
    
    // Handle 'i' and 'm' commands
    if (key === "i" || key === "I") {
      return "TOGGLE_IMAGE_CATALOG";
    }
    if (key === "m" || key === "M") {
      return "TOGGLE_AUDIO_CATALOG";
    }
    
    return "TOGGLE_FULLSCREEN";
  }
};
