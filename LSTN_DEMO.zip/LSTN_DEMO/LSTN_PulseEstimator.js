var LSTN = LSTN || {};

/**
 * Responsibility: convert raw audio level into a smoothed "pulse" value for visuals.
 * Handles both microphone and external audio file sources.
 */
LSTN.PulseEstimator = class {
  constructor(audioInput, spectrum) {
    this.audioInput = audioInput;
    this.spectrum = spectrum;
    this.smoothedPulse = 0;
  }

  update() {
    let level;

    // Check if using external audio (MP3)
    if (this.audioInput.useExternal && this.audioInput.externalAudio) {
      // Using FFT energy from spectrum analyzer
      if (this.spectrum && this.spectrum.fft) {
        this.spectrum.fft.analyze();
        level = this.spectrum.fft.getEnergy("bass") / 255; // 0.0 to 1.0
        level *= 0.8; // reduce effect to make visuals less reactive
        level = constrain(level, 0, 1);
      } else {
        level = 0;
      }
    } else {
      // Using microphone
      level = this.audioInput.getLevel(); // 0.0 to 0.2 typically
    }

    // Smooth the pulse (increased smoothing from 0.15 to 0.10 for slower response)
    const target = map(level, 0, 1, 0.3, 1.8, true);
    this.smoothedPulse = lerp(this.smoothedPulse, target, 0.10);
    return this.smoothedPulse;
  }
};
