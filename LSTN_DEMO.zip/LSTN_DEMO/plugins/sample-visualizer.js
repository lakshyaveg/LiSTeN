var LSTN = LSTN || {};

/**
 * Sample Visualizer Plugin
 * Demonstrates the plugin API and lifecycle hooks
 * This plugin adds floating particles that react to audio
 */
LSTN.SampleVisualizerPlugin = class extends LSTN.Plugin {
  constructor(api) {
    super(api);
    this.name = 'SampleVisualizer';
    this.version = '1.0.0';
    this.description = 'Sample plugin with floating particles that react to audio pulse';

    this.particles = [];
    this.maxParticles = 20;
  }

  async init() {
    this.api.log('Sample Visualizer plugin initialized!');
    this.api.log('This plugin adds floating particles that react to audio');
  }

  setup() {
    // Initialize particles
    this.particles = [];
    for (let i = 0; i < this.maxParticles; i++) {
      this.particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: Math.random() * 4 - 2,
        vy: Math.random() * 4 - 2,
        size: Math.random() * 10 + 5,
        hue: Math.random() * 360
      });
    }
  }

  update(pulse) {
    // Update particle positions
    for (let particle of this.particles) {
      particle.x += particle.vx;
      particle.y += particle.vy;

      // Bounce off edges
      if (particle.x < 0 || particle.x > width) particle.vx *= -1;
      if (particle.y < 0 || particle.y > height) particle.vy *= -1;

      // Wrap around edges instead (more elegant)
      particle.x = (particle.x + width) % width;
      particle.y = (particle.y + height) % height;

      // React to audio pulse
      if (pulse > 0.5) {
        particle.vx += Math.random() * 1 - 0.5;
        particle.vy += Math.random() * 1 - 0.5;
      }

      // Limit velocity
      const maxV = 3;
      particle.vx = Math.max(-maxV, Math.min(maxV, particle.vx));
      particle.vy = Math.max(-maxV, Math.min(maxV, particle.vy));
    }
  }

  draw(baseHue, pulse) {
    // Draw particles
    push();
    noStroke();

    for (let particle of this.particles) {
      // Color based on audio and base hue
      const hue = (baseHue + particle.hue + pulse * 60) % 360;
      const saturation = 200 + pulse * 55;
      const brightness = 150 + pulse * 105;

      fill(hue, saturation, brightness, 180);

      // Draw particle
      ellipse(particle.x, particle.y, particle.size);
    }

    pop();
  }

  onKeyPress(key, keyCode) {
    // Example: Press 'P' to toggle particles
    if (key === 'p' || key === 'P') {
      this.api.log('P key pressed - you could add toggle logic here');
    }
  }

  cleanup() {
    this.api.log('Sample Visualizer plugin cleaned up');
    this.particles = [];
  }
};
