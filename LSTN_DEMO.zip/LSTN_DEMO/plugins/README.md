# LSTN Plugin System

The LSTN Plugin Architecture allows developers to extend the LSTN audio visualizer without modifying core source code. Plugins can add new visualizations, effects, interactions, and more.

## Overview

The plugin system provides:
- **Dynamic Loading**: Plugins are automatically discovered and loaded from a manifest
- **Lifecycle Hooks**: Plugins integrate with setup, update, draw, and input events
- **Controlled API**: Plugins have safe, limited access to app state and audio data
- **No Core Modification**: Extend functionality without touching core files

## Architecture

### Components

#### 1. **LSTN_Plugin.js** - Base Plugin Class
The foundation for all plugins. Extend this class to create custom plugins.

```javascript
class LSTN.Plugin {
  // Lifecycle hooks
  async init()           // Called when plugin loads
  setup()               // Called during p5.js setup
  update(pulse)         // Called each frame for logic
  draw(baseHue, pulse)  // Called each frame for rendering
  onKeyPress(key, keyCode)  // Called on key press
  onMousePressed()      // Called on mouse press
  cleanup()             // Called when plugin unloads
}
```

#### 2. **LSTN_PluginManager.js** - Plugin Manager
Manages plugin loading, lifecycle, and coordination.

Key methods:
- `loadPlugins()` - Load all plugins from manifest
- `getPlugin(name)` - Get a plugin by name
- `getPlugins()` - Get all loaded plugins
- `callHook(hookName, ...args)` - Call a hook on all plugins
- `unloadPlugin(name)` - Unload a specific plugin
- `unloadAll()` - Unload all plugins

#### 3. **plugins/manifest.json** - Plugin Configuration
JSON file that defines which plugins to load and their settings.

```json
{
  "version": "1.0.0",
  "plugins": [
    {
      "name": "MyPlugin",
      "path": "./plugins/my-plugin.js",
      "enabled": true,
      "description": "What the plugin does"
    }
  ]
}
```

## Plugin API

Each plugin receives an `api` object with these methods:

### `getAppState()`
Returns the current application state.

```javascript
const state = this.api.getAppState();
// Returns: { mode: "normal"|"advanced", bounceEnabled: boolean, rotateEnabled: boolean, ... }
```

### `getAudioData()`
Returns current audio information.

```javascript
const audioData = this.api.getAudioData();
// Returns: { spectrum: Float32Array, pulse: number, volume: number }
```

### `log(message)`
Log to console with plugin prefix.

```javascript
this.api.log('Plugin message');  // Console: [PluginName] Plugin message
```

### `error(message)`
Log error to console with plugin prefix.

```javascript
this.api.error('Something went wrong');  // Console: [PluginName] Something went wrong
```

## Lifecycle Hooks

### 1. `init()` - Initialization
Called when the plugin is loaded.
- Perfect for one-time setup and logging
- Can be async

```javascript
async init() {
  this.api.log('Plugin initialized!');
  // Perform async setup if needed
  await this.loadResources();
}
```

### 2. `setup()` - p5.js Setup
Called during p5.js setup() when the canvas is ready.
- Initialize p5.js variables, particles, etc.
- Called once at startup

```javascript
setup() {
  this.particles = [];
  for (let i = 0; i < 10; i++) {
    this.particles.push({
      x: random(width),
      y: random(height)
    });
  }
}
```

### 3. `update(pulse)` - Logic Update
Called every frame before drawing.
- Update positions, states, etc.
- `pulse` parameter: audio pulse intensity (0-1)

```javascript
update(pulse) {
  for (let p of this.particles) {
    p.x += random(-2, 2);
    p.y += random(-2, 2) + pulse * 5;  // React to audio
  }
}
```

### 4. `draw(baseHue, pulse)` - Rendering
Called every frame for drawing.
- Draw custom visualizations
- `baseHue`: Current base color hue (0-360)
- `pulse`: Audio pulse intensity (0-1)

```javascript
draw(baseHue, pulse) {
  push();
  fill(baseHue, 200, 200);
  for (let p of this.particles) {
    ellipse(p.x, p.y, 10);
  }
  pop();
}
```

### 5. `onKeyPress(key, keyCode)` - Key Input
Called when a key is pressed.
- Respond to user keyboard input
- `key`: Character (e.g., 'a', 'A', '1')
- `keyCode`: Key code (e.g., 65 for 'A')

```javascript
onKeyPress(key, keyCode) {
  if (key === 'p' || key === 'P') {
    this.toggleParticles();
  }
}
```

### 6. `onMousePressed()` - Mouse Input
Called when the mouse is pressed.
- Respond to mouse clicks
- Can access p5.js globals: `mouseX`, `mouseY`, `pmouseX`, `pmouseY`

```javascript
onMousePressed() {
  this.particles.push({
    x: mouseX,
    y: mouseY
  });
}
```

### 7. `cleanup()` - Cleanup
Called when the plugin is unloaded.
- Clean up resources
- Stop running processes

```javascript
cleanup() {
  this.api.log('Plugin cleaning up');
  this.particles = [];
}
```

## Creating a Plugin

### Step 1: Create Plugin File
Create a new JavaScript file in `plugins/` directory.

```javascript
// plugins/my-awesome-plugin.js
var LSTN = LSTN || {};

LSTN.MyAwesomePlugin = class extends LSTN.Plugin {
  constructor(api) {
    super(api);
    this.name = 'MyAwesomePlugin';
    this.version = '1.0.0';
    this.description = 'Does something awesome';
  }

  async init() {
    this.api.log('Awesome plugin loaded!');
  }

  setup() {
    // Initialize p5.js resources
  }

  update(pulse) {
    // Update logic each frame
  }

  draw(baseHue, pulse) {
    // Draw your awesome visualization
  }

  cleanup() {
    this.api.log('Awesome plugin cleaned up');
  }
};
```

### Step 2: Register in Manifest
Add your plugin to `plugins/manifest.json`:

```json
{
  "version": "1.0.0",
  "plugins": [
    {
      "name": "MyAwesomePlugin",
      "path": "./plugins/my-awesome-plugin.js",
      "enabled": true,
      "description": "Does something awesome"
    }
  ]
}
```

### Step 3: Test
The plugin will automatically load when the app starts!

## Example Plugin: Floating Particles

```javascript
var LSTN = LSTN || {};

LSTN.FloatingParticlesPlugin = class extends LSTN.Plugin {
  constructor(api) {
    super(api);
    this.name = 'FloatingParticles';
    this.particles = [];
    this.maxParticles = 50;
  }

  async init() {
    this.api.log('Floating particles loaded');
  }

  setup() {
    for (let i = 0; i < this.maxParticles; i++) {
      this.particles.push({
        x: random(width),
        y: random(height),
        vx: random(-1, 1),
        vy: random(-1, 1),
        size: random(3, 8),
        hue: random(360)
      });
    }
  }

  update(pulse) {
    for (let p of this.particles) {
      p.x += p.vx;
      p.y += p.vy;
      
      // Bounce edges
      if (p.x < 0 || p.x > width) p.vx *= -1;
      if (p.y < 0 || p.y > height) p.vy *= -1;
      
      // React to pulse
      if (pulse > 0.6) {
        p.vx += random(-0.5, 0.5);
        p.vy += random(-0.5, 0.5);
      }
    }
  }

  draw(baseHue, pulse) {
    push();
    noStroke();
    
    for (let p of this.particles) {
      const hue = (baseHue + p.hue) % 360;
      fill(hue, 200, 200, 200);
      ellipse(p.x, p.y, p.size);
    }
    
    pop();
  }

  cleanup() {
    this.particles = [];
  }
};
```

## Best Practices

1. **Error Handling**: Wrap plugin code in try-catch blocks
2. **Performance**: Keep draw() and update() efficient
3. **Cleanup**: Always clean up resources in cleanup()
4. **Logging**: Use the provided logging API for debugging
5. **State**: Store state in instance variables, not globals
6. **p5.js**: Only use p5.js functions inside setup() and draw()
7. **Testing**: Test in both normal and advanced modes

## Security Considerations

- Plugins run with full access to the app
- Only load plugins from trusted sources
- No sandboxing currently implemented
- Malicious plugins could read all audio/state data

## Troubleshooting

### Plugin not loading
- Check browser console for error messages
- Verify manifest.json exists and is valid JSON
- Ensure plugin file path is correct
- Check that plugin exports correct class name

### Plugin not appearing in visualization
- Verify `draw()` method is implemented
- Check if plugin is disabled in manifest
- Ensure hook names match exactly
- Use `this.api.log()` to debug

### Audio data not available
- Verify you're calling `getAudioData()` from within the plugin
- Check that audio input is enabled
- Audio data is only available after setup

## File Structure

```
LSTNpre/
├── LSTN_Plugin.js         # Base plugin class
├── LSTN_PluginManager.js  # Plugin manager
├── plugins/
│   ├── manifest.json           # Plugin configuration
│   ├── sample-visualizer.js    # Example plugin
│   └── your-plugin.js          # Your custom plugin
└── [other core files...]
```

## Testing Your Plugin

Open the browser console (F12) while running the app:

1. Look for plugin loading messages
2. Check for any error messages
3. Use `LSTN_APP.pluginManager.getPlugins()` to see loaded plugins
4. Use `LSTN_APP.pluginManager.getPlugin('PluginName')` to inspect a plugin

Example console commands:
```javascript
// Get all plugins
LSTN_APP.pluginManager.getPlugins()

// Get specific plugin
LSTN_APP.pluginManager.getPlugin('SampleVisualizer')

// Get audio data
LSTN_APP.pluginManager.createPluginAPI('Test').getAudioData()

// Unload a plugin
LSTN_APP.pluginManager.unloadPlugin('SampleVisualizer')
```
