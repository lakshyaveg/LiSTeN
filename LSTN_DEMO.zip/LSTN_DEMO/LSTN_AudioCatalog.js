var LSTN = LSTN || {};

/**
 * Responsibility: display audio catalog with grid layout, pagination, and selection.
 * Uses local audio files referenced by relative path.
 */
LSTN.AudioCatalog = class {
  constructor(onAudioSelected, onCatalogClosed) {
    this.onAudioSelected = onAudioSelected;
    this.onCatalogClosed = onCatalogClosed || function() {};
    this.isOpen = false;
    this.currentPage = 0;
    this.itemsPerPage = 6; // 3 columns x 2 rows
    this.itemsPerRow = 3;
    
    // Local audio files: add audio files to your workspace and reference them here.
    // Example: { name: "MyAudio", data: "audio/MyAudio.mp3" }
    // If you add files in the root, use relative paths from index-1.html.
    this.items = [
      { name: "Sample 1", data: "audio/sample1.mp3" },
      { name: "Sample 2", data: "audio/sample2.mp3" },
      { name: "Sample 3", data: "audio/sample3.mp3" },
      { name: "Sample 4", data: "audio/sample4.mp3" },
      { name: "Sample 5", data: "audio/sample5.mp3" },
      { name: "Sample 6", data: "audio/sample6.mp3" }
      // { name: "OtherAudio", data: "audio/OtherAudio.wav" },
    ];

    this.hoveredIndex = null;
    this.pendingSelection = null;
  }

  toggle() {
    this.isOpen = !this.isOpen;
    if (this.isOpen) {
      this.currentPage = 0;
    }
  }

  open() {
    this.isOpen = true;
    this.currentPage = 0;
  }

  close() {
    this.isOpen = false;
  }

  handleMousePressed(mouseX, mouseY) {
    if (!this.isOpen) return;

    if (this.pendingSelection) {
      if (this.handleChoiceClick(mouseX, mouseY)) {
        return;
      }
      return;
    }

    const index = this.getItemIndexAtMouse(mouseX, mouseY);
    if (index !== null && index < this.items.length) {
      const item = this.items[index];
      if (item.data) {
        this.pendingSelection = item;
      }
    }
  }

  handleKeyPressed(key) {
    if (!this.isOpen) return;

    if (this.pendingSelection) {
      if (keyCode === ESCAPE || key === "Escape") {
        this.pendingSelection = null;
      }
      return;
    }

    if (key === "ArrowLeft" || key === "Left") {
      this.previousPage();
    } else if (key === "ArrowRight" || key === "Right") {
      this.nextPage();
    } else if (keyCode === ESCAPE || key === "Escape") {
      this.close();
    }
  }

  nextPage() {
    const maxPage = Math.ceil(this.items.length / this.itemsPerPage) - 1;
    if (this.currentPage < maxPage) {
      this.currentPage++;
    }
  }

  previousPage() {
    if (this.currentPage > 0) {
      this.currentPage--;
    }
  }

  handleChoiceClick(mouseX, mouseY) {
    const promptWidth = 300;
    const promptHeight = 150;
    const promptX = width / 2 - promptWidth / 2;
    const promptY = height / 2 - promptHeight / 2;
    const buttonW = 100;
    const buttonH = 40;
    const buttonY = promptY + promptHeight - 60;
    const playButtonX = promptX + promptWidth / 2 - buttonW / 2;

    if (
      mouseX >= playButtonX &&
      mouseX <= playButtonX + buttonW &&
      mouseY >= buttonY &&
      mouseY <= buttonY + buttonH
    ) {
      this.selectChoice("play");
      return true;
    }

    return false;
  }

  selectChoice(choice) {
    if (!this.pendingSelection) return;

    if (choice === "play") {
      this.onAudioSelected(this.pendingSelection);
      this.pendingSelection = null;
      this.close();
      this.onCatalogClosed();
    }
  }

  drawChoicePrompt() {
    const item = this.pendingSelection;
    if (!item) return;

    const promptW = 300;
    const promptH = 150;
    const promptX = width / 2 - promptW / 2;
    const promptY = height / 2 - promptH / 2;
    const buttonW = 100;
    const buttonH = 40;
    const buttonY = promptY + promptH - 60;
    const playButtonX = promptX + promptW / 2 - buttonW / 2;

    fill(30, 30, 30, 230);
    stroke(255);
    strokeWeight(2);
    rect(promptX, promptY, promptW, promptH, 12);

    fill(255);
    noStroke();
    textAlign(CENTER, TOP);
    textSize(16);
    text(`Play "${item.name}"?`, width / 2, promptY + 20);

    textSize(12);
    textStyle(NORMAL);
    text(
      "Click Play to start playing this audio.",
      width / 2,
      promptY + 50
    );

    // Button
    fill(255, 105, 180);
    rect(playButtonX, buttonY, buttonW, buttonH, 8);

    fill(255);
    textSize(14);
    textStyle(BOLD);
    text("Play", playButtonX + buttonW / 2, buttonY + buttonH / 2 - 8);

    textSize(11);
    textStyle(NORMAL);
    text("ESC to cancel", width / 2, promptY + promptH - 20);
  }

  getItemIndexAtMouse(mouseX, mouseY) {
    const startIdx = this.currentPage * this.itemsPerPage;
    const baseX = width / 2 - 180;
    const baseY = height / 2 - 140;
    const itemSize = 120;
    const spacing = 20;

    for (let i = 0; i < this.itemsPerPage; i++) {
      if (startIdx + i >= this.items.length) break;

      const row = Math.floor(i / this.itemsPerRow);
      const col = i % this.itemsPerRow;
      const x = baseX + col * (itemSize + spacing);
      const y = baseY + row * (itemSize + spacing);

      if (
        mouseX >= x &&
        mouseX < x + itemSize &&
        mouseY >= y &&
        mouseY < y + itemSize
      ) {
        return startIdx + i;
      }
    }
    return null;
  }

  draw() {
    if (!this.isOpen) return;

    push();
    resetMatrix();

    // Overlay background
    fill(0, 0, 0, 200);
    rect(0, 0, width, height);

    // Catalog container
    const containerW = 420;
    const containerH = 380;
    const containerX = width / 2 - containerW / 2;
    const containerY = height / 2 - containerH / 2;

    fill(255, 20, 147); // Deep pink
    stroke(255, 105, 180); // Hot pink border
    strokeWeight(3);
    rect(containerX, containerY, containerW, containerH, 10);

    // Title
    fill(255);
    textAlign(CENTER, TOP);
    textSize(20);
    textFont("Arial");
    textStyle(BOLD);
    text("AUDIO CATALOG", width / 2, containerY + 15);

    // Items grid
    const startIdx = this.currentPage * this.itemsPerPage;
    const baseX = containerX + 30;
    const baseY = containerY + 50;
    const itemSize = 100;
    const spacing = 20;

    for (let i = 0; i < this.itemsPerPage; i++) {
      const itemIdx = startIdx + i;
      if (itemIdx >= this.items.length) break;

      const row = Math.floor(i / this.itemsPerRow);
      const col = i % this.itemsPerRow;
      const x = baseX + col * (itemSize + spacing);
      const y = baseY + row * (itemSize + spacing);

      // Item background
      fill(255, 105, 180);
      stroke(255, 182, 193);
      strokeWeight(2);
      rect(x, y, itemSize, itemSize, 5);

      // Audio icon (music note)
      fill(255);
      textAlign(CENTER, CENTER);
      textSize(40);
      text("♪", x + itemSize / 2, y + itemSize / 2 - 5);

      // Item name (below the box)
      fill(255);
      noStroke();
      textAlign(CENTER, TOP);
      textSize(12);
      textStyle(NORMAL);
      text(this.items[itemIdx].name, x + itemSize / 2, y + itemSize + 5);
    }

    // Navigation info
    const maxPage = Math.ceil(this.items.length / this.itemsPerPage) - 1;
    fill(255);
    textAlign(CENTER, BOTTOM);
    textSize(12);
    text(
      `Page ${this.currentPage + 1} / ${maxPage + 1}  |  Arrow Keys to navigate  |  ESC to close`,
      width / 2,
      containerY + containerH - 10
    );

    if (this.pendingSelection) {
      this.drawChoicePrompt();
    }

    pop();
  }
};
