var LSTN = LSTN || {};

/**
 * Responsibility: manage microphone input lifecycle + provide current amplitude level.
 * Can also switch to an external audio source (e.g., MP3 file).
 */
LSTN.AudioInput = class {
  constructor() {
    this.mic = new p5.AudioIn();
    this.externalAudio = null;
    this.useExternal = false;
  }

  start() {
    try {
      this.mic.start();
      // Keep mic gain configuration here (input concern)
      this.mic.amp(2.0);
      console.log("Microphone started successfully");
    } catch (error) {
      console.warn("Microphone access error (this is OK, user may have denied permission):", error);
    }
  }

  setExternalAudio(audioSource) {
    this.externalAudio = audioSource;
    this.useExternal = true;
    console.log("Switched to external audio source");
  }

  getLevel() {
    if (this.useExternal && this.externalAudio) {
      // For p5.SoundFile, use getVolume() which gives 0-1 range
      if (typeof this.externalAudio.getVolume === 'function') {
        return this.externalAudio.getVolume();
      }
      // Fallback to amplitude
      if (typeof this.externalAudio.amp === 'function') {
        return this.externalAudio.amp();
      }
      return 0;
    }
    return this.mic.getLevel();
  }

  getMic() {
    return this.mic;
  }

  getAudioSource() {
    if (this.useExternal && this.externalAudio) {
      return this.externalAudio;
    }
    return this.mic;
  }
};
