var LSTN = LSTN || {};

/**
 * Responsibility: route raw input events to commands (no direct app side-effects).
 */
LSTN.InputController = class {
  constructor(deps) {
    this.bindings = deps.bindings;     // KeyBindings
    this.commands = deps.commands;     // AppCommands
    this.state = deps.state;           // AppState (for mode info)
  }

  handleKeyPress(key, keyCode) {
    const commandName = this.bindings.getCommandForKey(key, keyCode, this.state.mode);
    this.commands.execute(commandName);
  }
};
