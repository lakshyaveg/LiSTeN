var LSTN = LSTN || {};

/**
 * Plugin Manager - handles loading, managing, and coordinating plugins
 * Loads plugins from a manifest file and manages their lifecycle
 */
LSTN.PluginManager = class {
  constructor() {
    this.plugins = [];
    this.loadedPlugins = new Map();
    this.manifestPath = './plugins/manifest.json';
  }

  /**
   * Load plugins from manifest file
   */
  async loadPlugins() {
    try {
      const response = await fetch(this.manifestPath);
      if (!response.ok) {
        console.warn('Plugin manifest not found at ' + this.manifestPath + ', skipping plugin loading');
        return;
      }

      const manifest = await response.json();
      console.log('Plugin manifest loaded, loading ' + (manifest.plugins ? manifest.plugins.length : 0) + ' plugins');

      if (!manifest.plugins || !Array.isArray(manifest.plugins)) {
        console.warn('Invalid plugin manifest: no plugins array');
        return;
      }

      for (const pluginConfig of manifest.plugins) {
        await this.loadPlugin(pluginConfig);
      }
    } catch (error) {
      console.error('Error loading plugins:', error);
    }
  }

  /**
   * Load a single plugin by configuration
   */
  async loadPlugin(pluginConfig) {
    try {
      const { name, path, className, enabled = true } = pluginConfig;

      if (!enabled) {
        console.log('Plugin ' + name + ' is disabled, skipping');
        return;
      }

      if (!name || !path) {
        console.error('Invalid plugin config: missing name or path', pluginConfig);
        return;
      }

      console.log('Loading plugin: ' + name + ' from ' + path);

      // Dynamically load the plugin script
      await this._loadPluginScript(path);

      // Get the plugin class from the className or construct it
      const resolvedClassName = className || ('LSTN.' + name + 'Plugin');
      const PluginClass = this._getPluginClass(resolvedClassName);

      if (!PluginClass) {
        throw new Error('Plugin ' + name + ' class not found: ' + resolvedClassName);
      }

      // Create plugin instance with API
      const plugin = new PluginClass(this.createPluginAPI(name));
      plugin.name = name;
      plugin.config = pluginConfig;

      // Call init hook
      if (typeof plugin.init === 'function') {
        await plugin.init();
      }

      this.loadedPlugins.set(name, plugin);
      this.plugins.push(plugin);

      console.log('Plugin ' + name + ' loaded successfully');
    } catch (error) {
      console.error('Failed to load plugin ' + pluginConfig.name + ':', error);
    }
  }

  /**
   * Load a plugin script dynamically
   * Appends a script tag to load the plugin
   */
  async _loadPluginScript(path) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = path;
      script.type = 'text/javascript';
      
      script.onload = () => {
        resolve();
      };
      
      script.onerror = () => {
        reject(new Error('Failed to load script: ' + path));
      };
      
      document.head.appendChild(script);
    });
  }

  /**
   * Get a plugin class by dotted path name
   * e.g., "LSTN.SampleVisualizerPlugin" or "window.MyPlugin"
   */
  _getPluginClass(classPath) {
    const parts = classPath.split('.');
    let obj = window;
    
    for (const part of parts) {
      obj = obj[part];
      if (!obj) {
        return null;
      }
    }
    
    // Verify it's a function (class)
    if (typeof obj === 'function') {
      return obj;
    }
    
    return null;
  }

  /**
   * Create the plugin API object passed to each plugin
   * This controls what functionality plugins can access
   */
  createPluginAPI(pluginName) {
    return {
      // Core app access (limited for security)
      getAppState: () => {
        return window.LSTN_APP && window.LSTN_APP.state ? window.LSTN_APP.state : null;
      },

      // Access audio data
      getAudioData: () => {
        if (!window.LSTN_APP) return { spectrum: [], pulse: 0, volume: 0 };
        return {
          spectrum: window.LSTN_APP.spectrum && typeof window.LSTN_APP.spectrum.getSpectrum === 'function' 
            ? window.LSTN_APP.spectrum.getSpectrum() 
            : [],
          pulse: window.LSTN_APP.pulseEstimator && typeof window.LSTN_APP.pulseEstimator.getCurrentPulse === 'function'
            ? window.LSTN_APP.pulseEstimator.getCurrentPulse()
            : 0,
          volume: window.LSTN_APP.audioInput && typeof window.LSTN_APP.audioInput.getVolume === 'function'
            ? window.LSTN_APP.audioInput.getVolume()
            : 0
        };
      },

      // Utility logging
      log: (message) => {
        console.log('[' + pluginName + '] ' + message);
      },

      error: (message) => {
        console.error('[' + pluginName + '] ' + message);
      }
    };
  }

  /**
   * Call a lifecycle hook on all plugins
   */
  async callHook(hookName, ...args) {
    const results = [];

    for (const plugin of this.plugins) {
      if (plugin && typeof plugin[hookName] === 'function') {
        try {
          const result = await plugin[hookName](...args);
          results.push(result);
        } catch (error) {
          console.error('Error in plugin ' + plugin.name + ' hook ' + hookName + ':', error);
        }
      }
    }

    return results;
  }

  /**
   * Get all loaded plugins
   */
  getPlugins() {
    return this.plugins;
  }

  /**
   * Get a specific plugin by name
   */
  getPlugin(name) {
    return this.loadedPlugins.get(name);
  }

  /**
   * Unload a plugin
   */
  unloadPlugin(name) {
    const plugin = this.loadedPlugins.get(name);
    if (!plugin) return false;

    // Call cleanup if available
    if (typeof plugin.cleanup === 'function') {
      plugin.cleanup();
    }

    this.loadedPlugins.delete(name);
    this.plugins = this.plugins.filter((p) => p.name !== name);

    console.log('Plugin ' + name + ' unloaded');
    return true;
  }

  /**
   * Unload all plugins
   */
  unloadAll() {
    const names = Array.from(this.loadedPlugins.keys());
    for (const name of names) {
      this.unloadPlugin(name);
    }
  }

  /**
   * Debug helper: Log plugin loading status
   */
  logStatus() {
    console.log('=== Plugin Manager Status ===');
    console.log('Loaded plugins: ' + this.plugins.length);
    for (const plugin of this.plugins) {
      console.log('  - ' + plugin.name + ' v' + plugin.version);
    }
    console.log('=============================');
  }
};
