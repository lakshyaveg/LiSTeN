var LSTN = LSTN || {};

/**
 * Responsibility: provide app-level commands (side effects) for input/controller layers to call.
 */
LSTN.AppCommands = class {
  constructor(deps) {
    this.state = deps.state;
    this.visuals = deps.visuals;
    this.motion = deps.motion;
    this.display = deps.display;
    this.ui = deps.ui;
    this.backgrounds = deps.backgrounds;
    this.editor = deps.editor;
    this.imageCatalog = deps.imageCatalog;
    this.audioCatalog = deps.audioCatalog;
  }

  execute(commandName) {
    switch (commandName) {
      case "SET_HEART":
        if (this.state.mode === "normal") {
          this.visuals.setHeart();
        }
        break;

      case "PREVIOUS_BG_COLOR":
        this.backgrounds.cyclePreviousColor();
        break;

      case "NEXT_BG_COLOR":
        this.backgrounds.cycleNextColor();
        break;

      case "TOGGLE_ROTATE":
        if (this.state.mode === "normal") {
          this.state.toggleRotate();
        } else {
          this.editor.toggleSelectedItemRotate();
        }
        break;

      case "TOGGLE_BOUNCE":
        if (this.state.mode === "normal") {
          this.state.toggleBounce();
          if (this.state.bounceEnabled) this.motion.randomizeVelocity();
        } else {
          this.editor.toggleSelectedItemBounce();
        }
        break;

      case "TOGGLE_INSTRUCTIONS":
        this.state.toggleInstructions();
        break;

      case "TOGGLE_MODE":
        this.state.toggleMode();
        break;

      case "DELETE_SELECTED":
        if (this.state.mode === "advanced") {
          this.editor.deleteSelectedItem();
        }
        break;

      case "SET_HEART_TYPE":
        if (this.state.mode === "advanced") {
          this.editor.changeSelectedItemType("heart");
        }
        break;

      case "UPLOAD_IMAGE_FOR_SELECTED":
        if (this.state.mode === "advanced") {
          this.ui.triggerImageUploadForEditor();
        }
        break;

      case "TOGGLE_IMAGE_CATALOG":
        if (this.imageCatalog) {
          if (this.state.mode === "advanced") {
            if (this.editor.selectedItem) {
              this.imageCatalog.setDirectTarget("heart");
            } else {
              this.imageCatalog.setDirectTarget("background");
            }
          } else {
            this.imageCatalog.setDirectTarget(null);
          }
        }
        this.state.toggleImageCatalog();
        if (this.imageCatalog) {
          this.imageCatalog.toggle();
        }
        break;

      case "TOGGLE_AUDIO_CATALOG":
        if (this.state.mode === "normal") {
          this.state.toggleAudioCatalog();
          if (this.audioCatalog) {
            this.audioCatalog.toggle();
          }
        }
        break;

      case "RESET_ALL":
        // Reset state to defaults
        this.state.rotateEnabled = false;
        this.state.bounceEnabled = false;
        this.state.showInstructions = true;
        this.state.showImageCatalog = false;
        this.state.showAudioCatalog = false;
        this.state.mode = "normal";
        
        // Reset backgrounds
        this.backgrounds.colorIndex = 0;
        this.backgrounds.backgroundImage = null;
        
        // Reset visuals to heart
        this.visuals.setHeart();
        
        // Clear editor items
        this.editor.clear();
        
        // Close catalogs if open
        if (this.imageCatalog && this.imageCatalog.isOpen) {
          this.imageCatalog.close();
        }
        if (this.audioCatalog && this.audioCatalog.isOpen) {
          this.audioCatalog.close();
        }
        
        // Clear image cache to free memory
        if (window.imageLoader) {
          window.imageLoader.clearCache();
        }
        
        // Reset motion to center (bounce disabled)
        this.motion.resetToCenter();
        this.motion.velX = 0;
        this.motion.velY = 0;
        break;

      case "TOGGLE_FULLSCREEN":
      default:
        this.display.toggleFullscreen();
        break;
    }
  }
};
