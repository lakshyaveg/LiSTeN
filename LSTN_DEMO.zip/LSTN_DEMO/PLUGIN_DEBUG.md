## Plugin System Debugging Guide

If you see plugin loading errors in the browser console, here's how to debug:

### Console Commands

1. **Check if plugins loaded:**
   ```javascript
   LSTN_APP.pluginManager.getPlugins()
   ```
   Should return an array with loaded plugins.

2. **Get status:**
   ```javascript
   LSTN_APP.pluginManager.logStatus()
   ```
   Shows formatted list of loaded plugins.

3. **Check if a plugin exists:**
   ```javascript
   LSTN_APP.pluginManager.getPlugin('SampleVisualizer')
   ```

4. **Test audio data access:**
   ```javascript
   LSTN_APP.pluginManager.createPluginAPI('Test').getAudioData()
   ```

### Common Issues

#### "Plugin class not found after loading"
- Check that the `className` in manifest.json matches the actual class name in the plugin file
- Example: If manifest has `"className": "LSTN.SampleVisualizerPlugin"`, the plugin must define `LSTN.SampleVisualizerPlugin`

#### Plugin file failing to load
- Verify the file path is correct (relative to the HTML file)
- Check browser's Network tab to see if the script actually loads
- Look for 404 errors

#### Plugin loads but doesn't show visuals
- Verify the `draw()` method is implemented
- Check that hooks are being called with `LSTN_APP.pluginManager.logStatus()`
- Ensure plugin is not disabled in manifest.json

### Quick Test

After loading the app, run this in console:
```javascript
// Should show: Array [SampleVisualizerPlugin {}]
LSTN_APP.pluginManager.getPlugins()

// Should show: === Plugin Manager Status === ...
LSTN_APP.pluginManager.logStatus()

// Should show particles moving on screen
// and react to audio input
```

If you see all of these working, the plugin system is working correctly!
