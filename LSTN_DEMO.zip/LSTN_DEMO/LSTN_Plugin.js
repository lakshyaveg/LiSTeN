var LSTN = LSTN || {};

/**
 * Base Plugin class - defines the plugin interface and lifecycle hooks
 * Extend this class to create custom plugins
 */
LSTN.Plugin = class {
  constructor(api) {
    this.api = api;
    this.name = 'Unnamed Plugin';
    this.version = '1.0.0';
    this.description = '';
    this.enabled = true;
  }

  /**
   * Initialize the plugin (async)
   * Called when the plugin is loaded
   */
  async init() {
    this.api.log('Plugin initialized');
  }

  /**
   * Setup hook - called during p5.js setup
   * Use this to initialize p5.js related things
   */
  setup() {
    // Override in subclass
  }

  /**
   * Draw hook - called during each frame before visuals are rendered
   */
  draw(baseHue, pulse) {
    // Override in subclass
  }

  /**
   * Update hook - called before draw each frame for logic updates
   */
  update(pulse) {
    // Override in subclass
  }

  /**
   * Key press hook - called when a key is pressed
   */
  onKeyPress(key, keyCode) {
    // Override in subclass
  }

  /**
   * Mouse press hook - called when mouse is pressed
   */
  onMousePressed() {
    // Override in subclass
  }

  /**
   * Cleanup hook - called when plugin is unloaded
   */
  cleanup() {
    this.api.log('Plugin cleanup');
  }

  /**
   * Get plugin metadata
   */
  getMetadata() {
    return {
      name: this.name,
      version: this.version,
      description: this.description
    };
  }
};
