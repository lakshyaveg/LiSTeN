var LSTN = LSTN || {};

/**
 * Responsibility: render the on-screen instruction text.
 */
LSTN.InstructionOverlay = class {
  constructor(backgroundManager) {
    this.backgroundManager = backgroundManager;
    this.marginX = 20;
    this.marginBottom = 165;
  }

  draw(shouldShow) {
    if (!shouldShow) return;

    const currentBackground = this.backgroundManager.getCurrentColorName();
    const textValue =
      "Upload PNG or GIF (main visual)\n" +
      "Upload PNG or GIF (background)\n" +
      "ENTER = Heart\n" +
      "R = Rotate\n" +
      "B = Bounce\n" +
      "Left/Down Arrow = Previous BG Color\n" +
      "Right/Up Arrow = Next BG Color\n" +
      "BG Colors = Black, White, Red, Orange, Yellow, Green, Blue, Purple, Pink\n" +
      "Current BG Color = " + currentBackground + "\n" +
      "E = Instructions\n" +
      "Any Other Key = Fullscreen";

    textFont("Tahoma");
    resetMatrix();
    fill(255);
    textSize(14);
    textAlign(LEFT, TOP);
    text(textValue, this.marginX, height - this.marginBottom);
  }
};
