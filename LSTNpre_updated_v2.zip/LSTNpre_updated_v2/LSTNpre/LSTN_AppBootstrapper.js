var LSTN = LSTN || {};

/**
 * Responsibility: composition root (build + wire app dependencies).
 */
LSTN.AppBootstrapper = class {
  build() {
    // Core services
    console.log("Creating audio services...");
    const audioInput = new LSTN.AudioInput();
    const spectrum = new LSTN.SpectrumAnalyzer();
    const pulse = new LSTN.PulseEstimator(audioInput, spectrum);
    const imageLoader = new LSTN.ImageLoader();
    const audioFileLoader = new LSTN.AudioFileLoader();

    // Plugin system
    console.log("Creating plugin manager...");
    const pluginManager = new LSTN.PluginManager();

    // State + controllers
    console.log("Creating state and controllers...");
    const state = new LSTN.AppState();
    const motion = new LSTN.MotionController();
    const rotation = new LSTN.RotationController();
    const backgrounds = new LSTN.BackgroundManager();
    const overlay = new LSTN.InstructionOverlay(backgrounds);
    const visuals = new LSTN.VisualElementManager();
    const display = new LSTN.DisplayManager();
    const editor = new LSTN.AdvancedEditor();

    // UI
    console.log("Creating UI controller...");
    const uiController = new LSTN.UIController(
      (imageData) => {
        imageLoader.loadFromData(imageData, (img) => visuals.setUserImage(img));
      },
      (imageData) => {
        imageLoader.loadFromData(imageData, (img) => backgrounds.setBackgroundImage(img));
      },
      (imageData) => {
        imageLoader.loadFromData(imageData, (img) => {
          if (editor.selectedItem) {
            editor.setSelectedItemImage(img);
          }
        });
      },
      (file) => {
        audioFileLoader.load(file, (audio) => {
          audioInput.setExternalAudio(audio);
          spectrum.setInput(audio);
          console.log("MP3 audio loaded and connected to spectrum analyzer");
        });
      }
    );

    // Catalogs
    console.log("Creating catalogs...");
    const imageCatalog = new LSTN.ImageCatalog((imageData) => {
      imageLoader.loadFromData(imageData, (img) => visuals.setUserImage(img));
    });

    const audioCatalog = new LSTN.AudioCatalog((audioItem) => {
      // Load audio from catalog
      if (audioItem.data) {
        audioInput.setExternalAudio(audioItem.data);
        spectrum.setInput(audioItem.data);
        console.log("Audio catalog item loaded:", audioItem.name);
      }
    });

    // Input wiring
    console.log("Creating input controllers...");
    const bindings = new LSTN.KeyBindings();
    const commands = new LSTN.AppCommands({
      state,
      visuals,
      motion,
      display,
      ui: uiController,
      backgrounds,
      editor,
      imageCatalog,
      audioCatalog,
    });
    const input = new LSTN.InputController({ bindings, commands, state });

    // Final app runtime
    console.log("Creating VisualizerApp...");
    const app = new LSTN.VisualizerApp({
      audioInput,
      spectrum,
      pulse,
      state,
      motion,
      rotation,
      backgrounds,
      overlay,
      visuals,
      display,
      uiController,
      input,
      editor,
      pluginManager,
      imageCatalog,
      audioCatalog,
    });

    console.log("App built successfully!");
    return app;
  }
};
