let app;

console.log("main.js loaded");

async function setup() {
  try {
    console.log("Setup starting...");
    createCanvas(windowWidth - 16, windowHeight - 16);
    console.log("Canvas created:", windowWidth, windowHeight);
    
    angleMode(DEGREES);
    colorMode(HSB, 360, 255, 255, 255);
    noStroke();

    console.log("Creating bootstrapper...");
    const bootstrapper = new LSTN.AppBootstrapper();
    console.log("Building app...");
    app = bootstrapper.build();
    console.log("Starting app...");
    await app.start();
    console.log("App started successfully!");
  } catch (error) {
    console.error("Error during setup:", error);
    fill(255, 0, 0);
    textSize(24);
    textAlign(CENTER, CENTER);
    text("Setup Error: " + error.message, width / 2, height / 2);
  }
}

function draw() {
  if (!app) {
    // Show loading message while app initializes
    background(0);
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(24);
    text("Loading...", width / 2, height / 2);
    return;
  }
  
  try {
    app.draw();
  } catch (error) {
    console.error("Error in draw:", error);
    background(0);
    fill(255, 0, 0);
    textAlign(LEFT, TOP);
    textSize(14);
    text("Draw Error:\n" + error.message, 20, 20);
  }
}

function keyPressed() {
  if (app) {
    app.handleKeyPress(key, keyCode);
  }
}

function mousePressed() {
  if (app) {
    return app.handleMousePressed();
  }
  return false;
}

function mouseReleased() {
  if (app) {
    return app.handleMouseReleased();
  }
  return false;
}

function mouseDragged() {
  if (app) {
    return app.handleMouseDragged();
  }
  return false;
}

function windowResized() {
  if (app) {
    app.windowResized();
  }
}
