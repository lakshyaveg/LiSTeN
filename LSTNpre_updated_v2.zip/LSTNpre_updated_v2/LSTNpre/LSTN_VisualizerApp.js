var LSTN = LSTN || {};

/**
 * Responsibility: runtime coordinator (frame loop orchestration).
 * Construction/wiring is handled by AppBootstrapper.
 */
LSTN.VisualizerApp = class {
  constructor(deps) {
    this.audioInput = deps.audioInput;
    this.spectrum = deps.spectrum;
    this.pulseEstimator = deps.pulse;

    this.state = deps.state;
    this.motion = deps.motion;
    this.rotation = deps.rotation;
    this.backgrounds = deps.backgrounds;
    this.overlay = deps.overlay;
    this.visuals = deps.visuals;
    this.display = deps.display;

    this.uiController = deps.uiController;
    this.input = deps.input;
    this.editor = deps.editor;
    this.pluginManager = deps.pluginManager;

    this.imageCatalog = deps.imageCatalog;
    this.audioCatalog = deps.audioCatalog;

    // Connect FFT to mic once everything exists
    this.spectrum.setInput(this.audioInput.getMic());
  }

  async start() {
    this.audioInput.start();

    // Load plugins
    if (this.pluginManager) {
      await this.pluginManager.loadPlugins();

      // Make app globally accessible for plugins
      window.LSTN_APP = this;

      // Call setup hooks on plugins
      await this.pluginManager.callHook('setup');
    }
  }

  draw() {
    try {
      this.backgrounds.draw();

      // Draw catalogs if open
      if (this.state.showImageCatalog && this.imageCatalog) {
        this.imageCatalog.draw();
      }
      if (this.state.showAudioCatalog && this.audioCatalog) {
        this.audioCatalog.draw();
      }

      // Don't update game state if catalog is open
      if (this.state.showImageCatalog || this.state.showAudioCatalog) {
        return;
      }

      const pulse = this.pulseEstimator.update();

      // Call plugin update hooks
      if (this.pluginManager) {
        this.pluginManager.callHook('update', pulse);
      }

      if (this.state.mode === "normal") {
        this.drawNormalMode(pulse);
      } else if (this.state.mode === "advanced") {
        this.drawAdvancedMode(pulse);
      }

      this.overlay.draw(this.state.showInstructions, this.state.mode);
    } catch (error) {
      console.error("Error in draw loop:", error);
      fill(255);
      textAlign(CENTER, CENTER);
      textSize(24);
      text("Error: " + error.message, width / 2, height / 2);
    }
  }

  drawNormalMode(pulse) {
    // Update motion + rotation state
    this.motion.update(this.state.bounceEnabled, pulse);
    this.rotation.update(this.state.rotateEnabled);

    push();
    translate(this.motion.posX, this.motion.posY);
    this.rotation.apply(this.state.rotateEnabled);

    const baseHue = (frameCount * 2) % 360;
    this.visuals.draw(baseHue, pulse);

    // Call plugin draw hooks
    if (this.pluginManager) {
      this.pluginManager.callHook('draw', baseHue, pulse);
    }

    pop();
  }

  drawAdvancedMode(pulse) {
    const baseHue = (frameCount * 2) % 360;
    this.editor.update(pulse);
    this.editor.draw(baseHue, pulse, this.state.showInstructions);

    // Call plugin draw hooks
    if (this.pluginManager) {
      this.pluginManager.callHook('draw', baseHue, pulse);
    }
  }

  handleKeyPress(key, keyCode) {
    // Handle catalog navigation keys first
    if (this.state.showImageCatalog) {
      if (key === "ArrowLeft" || key === "Left") {
        this.imageCatalog.previousPage();
        return;
      } else if (key === "ArrowRight" || key === "Right") {
        this.imageCatalog.nextPage();
        return;
      } else if (keyCode === ESCAPE) {
        this.state.toggleImageCatalog();
        this.imageCatalog.close();
        return;
      }
    }

    if (this.state.showAudioCatalog) {
      if (key === "ArrowLeft" || key === "Left") {
        this.audioCatalog.previousPage();
        return;
      } else if (key === "ArrowRight" || key === "Right") {
        this.audioCatalog.nextPage();
        return;
      } else if (keyCode === ESCAPE) {
        this.state.toggleAudioCatalog();
        this.audioCatalog.close();
        return;
      }
    }

    this.input.handleKeyPress(key, keyCode);

    // Call plugin key press hooks
    if (this.pluginManager) {
      this.pluginManager.callHook('onKeyPress', key, keyCode);
    }
  }

  handleMousePressed() {
    // Handle catalog clicks first
    if (this.state.showImageCatalog) {
      this.imageCatalog.handleMousePressed(mouseX, mouseY);
      return false;
    }

    if (this.state.showAudioCatalog) {
      this.audioCatalog.handleMousePressed(mouseX, mouseY);
      return false;
    }

    if (this.state.mode === "advanced") {
      const item = this.editor.getSelectedItemAtMouse(mouseX, mouseY);
      this.editor.selectItem(item);
      
      // Start box drawing if nothing was clicked
      if (!item) {
        this.editor.startBoxDrawing(mouseX, mouseY);
      }
    }
    return false;
  }

  handleMouseReleased() {
    if (this.state.mode === "advanced" && this.editor.isDrawingBox) {
      this.editor.endBoxDrawing(mouseX, mouseY);
    }
    return false;
  }

  handleMouseDragged() {
    if (this.state.mode === "advanced") {
      if (this.editor.selectedItem && !this.editor.isDrawingBox) {
        // Allow dragging selected item
        this.editor.selectedItem.x += mouseX - pmouseX;
        this.editor.selectedItem.y += mouseY - pmouseY;
      }
    }
    return false;
  }

  windowResized() {
    this.display.handleWindowResized();
  }
};
