var LSTN = LSTN || {};

/**
 * Responsibility: display audio catalog with grid layout, pagination, and selection.
 * Pre-loaded with sample audio files.
 */
LSTN.AudioCatalog = class {
  constructor(onAudioSelected) {
    this.onAudioSelected = onAudioSelected;
    this.isOpen = false;
    this.currentPage = 0;
    this.itemsPerPage = 6; // 3 columns x 2 rows
    this.itemsPerRow = 3;

    // Pre-loaded sample audio files (you can replace with actual URLs or embedded data)
    this.items = [
      { name: "sample1", data: null },
      { name: "sample2", data: null },
      { name: "sample3", data: null },
      { name: "sample4", data: null },
      { name: "sample5", data: null },
      { name: "sample6", data: null },
    ];

    this.hoveredIndex = null;
  }

  toggle() {
    this.isOpen = !this.isOpen;
    if (this.isOpen) {
      this.currentPage = 0;
    }
  }

  open() {
    this.isOpen = true;
    this.currentPage = 0;
  }

  close() {
    this.isOpen = false;
  }

  handleMousePressed(mouseX, mouseY) {
    if (!this.isOpen) return;

    const index = this.getItemIndexAtMouse(mouseX, mouseY);
    if (index !== null && index < this.items.length) {
      const item = this.items[index];
      if (item.data) {
        this.onAudioSelected(item);
        this.close();
      }
    }
  }

  handleKeyPressed(key) {
    if (!this.isOpen) return;

    if (key === "ArrowLeft" || key === "Left") {
      this.previousPage();
    } else if (key === "ArrowRight" || key === "Right") {
      this.nextPage();
    } else if (keyCode === ESCAPE || key === "Escape") {
      this.close();
    }
  }

  nextPage() {
    const maxPage = Math.ceil(this.items.length / this.itemsPerPage) - 1;
    if (this.currentPage < maxPage) {
      this.currentPage++;
    }
  }

  previousPage() {
    if (this.currentPage > 0) {
      this.currentPage--;
    }
  }

  getItemIndexAtMouse(mouseX, mouseY) {
    const startIdx = this.currentPage * this.itemsPerPage;
    const baseX = width / 2 - 180;
    const baseY = height / 2 - 140;
    const itemSize = 120;
    const spacing = 20;

    for (let i = 0; i < this.itemsPerPage; i++) {
      if (startIdx + i >= this.items.length) break;

      const row = Math.floor(i / this.itemsPerRow);
      const col = i % this.itemsPerRow;
      const x = baseX + col * (itemSize + spacing);
      const y = baseY + row * (itemSize + spacing);

      if (
        mouseX >= x &&
        mouseX < x + itemSize &&
        mouseY >= y &&
        mouseY < y + itemSize
      ) {
        return startIdx + i;
      }
    }
    return null;
  }

  draw() {
    if (!this.isOpen) return;

    push();
    resetMatrix();

    // Overlay background
    fill(0, 0, 0, 200);
    rect(0, 0, width, height);

    // Catalog container
    const containerW = 420;
    const containerH = 380;
    const containerX = width / 2 - containerW / 2;
    const containerY = height / 2 - containerH / 2;

    fill(255, 20, 147); // Deep pink
    stroke(255, 105, 180); // Hot pink border
    strokeWeight(3);
    rect(containerX, containerY, containerW, containerH, 10);

    // Title
    fill(255);
    textAlign(CENTER, TOP);
    textSize(20);
    textFont("Arial");
    textStyle(BOLD);
    text("AUDIO CATALOG", width / 2, containerY + 15);

    // Items grid
    const startIdx = this.currentPage * this.itemsPerPage;
    const baseX = containerX + 30;
    const baseY = containerY + 50;
    const itemSize = 100;
    const spacing = 20;

    for (let i = 0; i < this.itemsPerPage; i++) {
      const itemIdx = startIdx + i;
      if (itemIdx >= this.items.length) break;

      const row = Math.floor(i / this.itemsPerRow);
      const col = i % this.itemsPerRow;
      const x = baseX + col * (itemSize + spacing);
      const y = baseY + row * (itemSize + spacing);

      // Item background
      fill(255, 105, 180);
      stroke(255, 182, 193);
      strokeWeight(2);
      rect(x, y, itemSize, itemSize, 5);

      // Audio icon (music note)
      fill(255);
      textAlign(CENTER, CENTER);
      textSize(40);
      text("♪", x + itemSize / 2, y + itemSize / 2 - 5);

      // Item name (below the box)
      fill(255);
      noStroke();
      textAlign(CENTER, TOP);
      textSize(12);
      textStyle(NORMAL);
      text(this.items[itemIdx].name, x + itemSize / 2, y + itemSize + 5);
    }

    // Navigation info
    const maxPage = Math.ceil(this.items.length / this.itemsPerPage) - 1;
    fill(255);
    textAlign(CENTER, BOTTOM);
    textSize(12);
    text(
      `Page ${this.currentPage + 1} / ${maxPage + 1}  |  Arrow Keys to navigate  |  ESC to close`,
      width / 2,
      containerY + containerH - 10
    );

    pop();
  }
};
