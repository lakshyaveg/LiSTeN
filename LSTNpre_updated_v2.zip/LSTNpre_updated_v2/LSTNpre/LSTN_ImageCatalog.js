var LSTN = LSTN || {};

/**
 * Responsibility: display image catalog with grid layout, pagination, and selection.
 * Pre-loaded with sample images.
 */
LSTN.ImageCatalog = class {
  constructor(onImageSelected) {
    this.onImageSelected = onImageSelected;
    this.isOpen = false;
    this.currentPage = 0;
    this.itemsPerPage = 6; // 3 columns x 2 rows
    this.itemsPerRow = 3;
    
    // Pre-loaded sample images - names only, created on demand
    this.items = [
      { name: "sample1", color: "#FF1493", data: null },
      { name: "sample2", color: "#FF69B4", data: null },
      { name: "sample3", color: "#FFB6C1", data: null },
      { name: "sample4", color: "#FF00FF", data: null },
      { name: "sample5", color: "#FF007F", data: null },
      { name: "sample6", color: "#FF1493", data: null },
    ];

    this.hoveredIndex = null;
    this.imagesCreated = false;
  }

  createSampleImage(colorHex) {
    // Create a simple colored circle as sample (p5 Image)
    let img = createImage(100, 100);
    img.loadPixels();
    let c = color(colorHex);
    for (let i = 0; i < img.pixels.length; i += 4) {
      img.pixels[i] = red(c);
      img.pixels[i + 1] = green(c);
      img.pixels[i + 2] = blue(c);
      img.pixels[i + 3] = 255;
    }
    img.updatePixels();
    return img;
  }

  ensureImagesCreated() {
    if (!this.imagesCreated) {
      for (let item of this.items) {
        if (item.color) {
          item.data = this.createSampleImage(item.color);
        }
      }
      this.imagesCreated = true;
    }
  }

  toggle() {
    this.isOpen = !this.isOpen;
    if (this.isOpen) {
      this.currentPage = 0;
    }
  }

  open() {
    this.isOpen = true;
    this.currentPage = 0;
  }

  close() {
    this.isOpen = false;
  }

  handleMousePressed(mouseX, mouseY) {
    if (!this.isOpen) return;

    const index = this.getItemIndexAtMouse(mouseX, mouseY);
    if (index !== null && index < this.items.length) {
      const item = this.items[index];
      this.onImageSelected(item.data);
      this.close();
    }
  }

  handleKeyPressed(key) {
    if (!this.isOpen) return;

    if (key === "ArrowLeft" || key === "Left") {
      this.previousPage();
    } else if (key === "ArrowRight" || key === "Right") {
      this.nextPage();
    } else if (keyCode === ESCAPE || key === "Escape") {
      this.close();
    }
  }

  nextPage() {
    const maxPage = Math.ceil(this.items.length / this.itemsPerPage) - 1;
    if (this.currentPage < maxPage) {
      this.currentPage++;
    }
  }

  previousPage() {
    if (this.currentPage > 0) {
      this.currentPage--;
    }
  }

  getItemIndexAtMouse(mouseX, mouseY) {
    const startIdx = this.currentPage * this.itemsPerPage;
    const baseX = width / 2 - 180;
    const baseY = height / 2 - 140;
    const itemSize = 120;
    const spacing = 20;

    for (let i = 0; i < this.itemsPerPage; i++) {
      if (startIdx + i >= this.items.length) break;

      const row = Math.floor(i / this.itemsPerRow);
      const col = i % this.itemsPerRow;
      const x = baseX + col * (itemSize + spacing);
      const y = baseY + row * (itemSize + spacing);

      if (
        mouseX >= x &&
        mouseX < x + itemSize &&
        mouseY >= y &&
        mouseY < y + itemSize
      ) {
        return startIdx + i;
      }
    }
    return null;
  }

  draw() {
    if (!this.isOpen) return;

    // Create images on first draw
    this.ensureImagesCreated();

    push();
    resetMatrix();

    // Overlay background
    fill(0, 0, 0, 200);
    rect(0, 0, width, height);

    // Catalog container
    const containerW = 420;
    const containerH = 380;
    const containerX = width / 2 - containerW / 2;
    const containerY = height / 2 - containerH / 2;

    fill(255, 20, 147); // Deep pink
    stroke(255, 105, 180); // Hot pink border
    strokeWeight(3);
    rect(containerX, containerY, containerW, containerH, 10);

    // Title
    fill(255);
    textAlign(CENTER, TOP);
    textSize(20);
    textFont("Arial");
    textStyle(BOLD);
    text("IMAGE CATALOG", width / 2, containerY + 15);

    // Items grid
    const startIdx = this.currentPage * this.itemsPerPage;
    const baseX = containerX + 30;
    const baseY = containerY + 50;
    const itemSize = 100;
    const spacing = 20;

    for (let i = 0; i < this.itemsPerPage; i++) {
      const itemIdx = startIdx + i;
      if (itemIdx >= this.items.length) break;

      const row = Math.floor(i / this.itemsPerRow);
      const col = i % this.itemsPerRow;
      const x = baseX + col * (itemSize + spacing);
      const y = baseY + row * (itemSize + spacing);

      // Item background
      fill(255, 105, 180);
      stroke(255, 182, 193);
      strokeWeight(2);
      rect(x, y, itemSize, itemSize, 5);

      // Item image
      const item = this.items[itemIdx];
      if (item.data) {
        tint(255, 255, 255, 220);
        imageMode(CENTER);
        image(item.data, x + itemSize / 2, y + itemSize / 2, 80, 80);
        noTint();
      }

      // Item name (below the box)
      fill(255);
      noStroke();
      textAlign(CENTER, TOP);
      textSize(12);
      textStyle(NORMAL);
      text(item.name, x + itemSize / 2, y + itemSize + 5);
    }

    // Navigation info
    const maxPage = Math.ceil(this.items.length / this.itemsPerPage) - 1;
    fill(255);
    textAlign(CENTER, BOTTOM);
    textSize(12);
    text(
      `Page ${this.currentPage + 1} / ${maxPage + 1}  |  Arrow Keys to navigate  |  ESC to close`,
      width / 2,
      containerY + containerH - 10
    );

    pop();
  }
};
